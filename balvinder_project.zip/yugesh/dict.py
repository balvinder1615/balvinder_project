cc={1:"neha",2:"heena"}

cc[1]="parneet"
cc.pop(2)
print(cc)