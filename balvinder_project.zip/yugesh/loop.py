i=0
while i<5:
    j=0
    while j<5:
        print(j," ",end="")
        j+=1
    print("\n")
    i+=1